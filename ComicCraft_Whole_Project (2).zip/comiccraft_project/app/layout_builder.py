def build_comic_layout(outline, story, image_paths):
    story_by_number = {item.get("panel_number", i + 1): item for i, item in enumerate(story)}
    layout = []
    for i, panel in enumerate(outline):
        number = panel.get("panel_number", i + 1)
        text = story_by_number.get(number, {})
        layout.append({
            "panel_number": number,
            "title": panel.get("title", f"Panel {number}"),
            "scene_description": panel.get("scene_description", ""),
            "image_prompt": panel.get("image_prompt", ""),
            "image_path": image_paths[i] if i < len(image_paths) else "",
            "narration": text.get("narration", ""),
            "dialogue": text.get("dialogue", ""),
            "caption": text.get("caption", ""),
        })
    return layout
