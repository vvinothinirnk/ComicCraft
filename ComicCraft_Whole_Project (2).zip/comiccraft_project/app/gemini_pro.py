"""Expand a panel outline into narration and dialogue."""
import json, os, re
try:
    from google import genai
except ImportError:
    genai = None


def generate_story(outline, character="Alex", tone="adventurous"):
    api_key = os.getenv("GEMINI_API_KEY")
    if api_key and genai is not None:
        client = genai.Client(api_key=api_key)
        model = os.getenv("GEMINI_PRO_MODEL", "gemini-2.5-pro")
        prompt = f"Expand this 5-panel comic outline into concise narration and dialogue. Character: {character}. Tone: {tone}. Return only JSON array with panel_number, narration, dialogue, caption. Outline: {json.dumps(outline)}"
        response = client.models.generate_content(model=model, contents=prompt)
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", (response.text or "").strip())
        try:
            story = json.loads(raw)
            if isinstance(story, list) and len(story) == len(outline):
                return story
        except json.JSONDecodeError:
            pass
    result = []
    for p in outline:
        result.append({
            "panel_number": p.get("panel_number", len(result) + 1),
            "narration": p.get("scene_description", "The adventure continues."),
            "dialogue": f'{character}: "Let’s see where this adventure leads!"',
            "caption": f"{tone.title()} moments in the story."
        })
    return result
