"""Generate illustrations through Hugging Face Inference API when configured.
A lightweight local SVG placeholder is used when no token is available, so the app runs immediately.
"""
import os, re, uuid
from pathlib import Path
from xml.sax.saxutils import escape

BASE_DIR = Path(__file__).resolve().parent
PANELS_DIR = BASE_DIR / "static" / "panels"
PANELS_DIR.mkdir(parents=True, exist_ok=True)


def generate_image(prompt: str, index: int = 1) -> str:
    token = os.getenv("HF_API_KEY")
    model = os.getenv("HF_IMAGE_MODEL", "stabilityai/stable-diffusion-xl-base-1.0")
    if token:
        try:
            from huggingface_hub import InferenceClient
            client = InferenceClient(model=model, token=token)
            image = client.text_to_image(prompt)
            filename = f"panel_{index}_{uuid.uuid4().hex[:8]}.png"
            path = PANELS_DIR / filename
            image.save(path)
            return f"/static/panels/{filename}"
        except Exception as exc:
            # Fall through to a clear local placeholder rather than failing the entire comic.
            print(f"Image API unavailable; using placeholder: {exc}")
    filename = f"panel_{index}_{uuid.uuid4().hex[:8]}.svg"
    path = PANELS_DIR / filename
    title = escape((prompt[:90] or "Comic adventure"))
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="900" height="560" viewBox="0 0 900 560">
    <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#312e81"/><stop offset="1" stop-color="#ec4899"/></linearGradient></defs>
    <rect width="900" height="560" fill="url(#g)"/><circle cx="730" cy="115" r="65" fill="#fde68a" opacity=".9"/>
    <path d="M0 430 Q160 280 320 430 T650 410 T900 400 V560 H0Z" fill="#111827" opacity=".55"/>
    <rect x="55" y="55" width="790" height="450" rx="28" fill="none" stroke="white" stroke-width="5" opacity=".8"/>
    <text x="450" y="235" text-anchor="middle" font-family="Arial,sans-serif" font-size="38" font-weight="bold" fill="white">COMICCRAFT</text>
    <foreignObject x="100" y="270" width="700" height="150"><div xmlns="http://www.w3.org/1999/xhtml" style="font:24px Arial;color:white;text-align:center;overflow-wrap:anywhere">{title}</div></foreignObject>
    </svg>'''
    path.write_text(svg, encoding="utf-8")
    return f"/static/panels/{filename}"
