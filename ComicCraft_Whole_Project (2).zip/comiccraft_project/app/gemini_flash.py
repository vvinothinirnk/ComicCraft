"""Generate a structured comic outline using the Gemini API.
If no API key is configured, a local demo outline is returned.
"""
import json, os, re

try:
    from google import genai
except ImportError:
    genai = None


def _demo_outline(prompt: str, character: str, setting: str, tone: str, art_style: str):
    beats = [
        ("A Curious Beginning", f"{character} discovers something unusual in {setting}.", "wide establishing shot"),
        ("The First Clue", f"A mysterious clue appears and {character} decides to investigate.", "close-up of a mysterious clue"),
        ("Unexpected Trouble", f"The situation becomes complicated, but {character} stays determined.", "dynamic action scene"),
        ("A Clever Plan", f"{character} uses creativity and courage to solve the problem.", "hero planning a clever solution"),
        ("A Bright Ending", f"The adventure ends with a meaningful discovery and a smile.", "uplifting cinematic final scene"),
    ]
    return [{"panel_number": i + 1, "title": title, "scene_description": scene,
             "image_prompt": f"{art_style} comic illustration, {shot}, {scene}, setting: {setting}, tone: {tone}, no text, coherent character design"}
            for i, (title, scene, shot) in enumerate(beats)]


def generate_outline(prompt: str, character: str = "Alex", setting: str = "a magical town", tone: str = "adventurous", art_style: str = "comic book"):
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key or genai is None:
        return _demo_outline(prompt, character, setting, tone, art_style)
    client = genai.Client(api_key=api_key)
    model = os.getenv("GEMINI_FLASH_MODEL", "gemini-2.5-flash")
    instruction = f'''Create exactly 5 comic panels for this idea: {prompt!r}. Main character: {character}. Setting: {setting}. Tone: {tone}. Art style: {art_style}.
Return ONLY valid JSON array. Every item must have panel_number (integer), title, scene_description, image_prompt. Keep the same character visually consistent. Do not include markdown fences.'''
    response = client.models.generate_content(model=model, contents=instruction)
    raw = (response.text or "").strip()
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw)
    data = json.loads(raw)
    if not isinstance(data, list) or len(data) != 5:
        raise ValueError("Gemini returned an invalid outline; expected five panels.")
    return data
