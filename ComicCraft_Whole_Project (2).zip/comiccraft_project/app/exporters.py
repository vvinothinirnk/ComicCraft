from pathlib import Path
from fpdf import FPDF
from urllib.parse import urlparse

BASE_DIR = Path(__file__).resolve().parent
EXPORTS_DIR = BASE_DIR / "static" / "exports"
EXPORTS_DIR.mkdir(parents=True, exist_ok=True)


def save_pdf(layout, title="My Comic"):
    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)
    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        heading = str(panel.get("title", "Comic Panel"))
        pdf.multi_cell(0, 10, heading.encode("latin-1", "replace").decode("latin-1"), align="C")
        image_path = panel.get("image_path", "")
        if image_path.startswith("/static/"):
            local = BASE_DIR / "static" / image_path.removeprefix("/static/")
            if local.exists() and local.suffix.lower() in {".png", ".jpg", ".jpeg"}:
                try:
                    pdf.image(str(local), x=20, y=35, w=170, h=95, keep_aspect_ratio=True)
                    pdf.set_y(137)
                except Exception:
                    pdf.ln(5)
            else:
                pdf.ln(5)
        pdf.set_font("Helvetica", "B", 12)
        for label, key in (("Scene", "scene_description"), ("Narration", "narration"), ("Dialogue", "dialogue"), ("Caption", "caption")):
            value = str(panel.get(key, "") or "")
            if value:
                pdf.multi_cell(0, 7, f"{label}: {value}".encode("latin-1", "replace").decode("latin-1"))
                pdf.ln(2)
    filename = f"comiccraft_{__import__('datetime').datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    path = EXPORTS_DIR / filename
    pdf.output(str(path))
    return f"/static/exports/{filename}"
