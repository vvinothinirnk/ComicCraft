from pathlib import Path
from typing import Optional
from fastapi import APIRouter, Form, Request, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel, Field
from app.gemini_flash import generate_outline
from app.gemini_pro import generate_story
from app.image_generator import generate_image
from app.layout_builder import build_comic_layout
from app.exporters import save_pdf

router = APIRouter()

class PromptRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=1500)
    character_name: str = "Alex"
    setting: str = "a magical town"
    tone: str = "adventurous"
    art_style: str = "comic book"


def create_comic(data: PromptRequest):
    outline = generate_outline(data.prompt, data.character_name, data.setting, data.tone, data.art_style)
    story = generate_story(outline, data.character_name, data.tone)
    images = [generate_image(p.get("image_prompt", p.get("scene_description", data.prompt)), i + 1) for i, p in enumerate(outline)]
    layout = build_comic_layout(outline, story, images)
    pdf_path = save_pdf(layout)
    return layout, pdf_path

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return request.app.state.templates.TemplateResponse(request=request, name="index.html", context={})

@router.post("/generate", response_class=HTMLResponse)
def generate_form(request: Request, prompt: str = Form(...), character_name: str = Form("Alex"), setting: str = Form("a magical town"), tone: str = Form("adventurous"), art_style: str = Form("comic book")):
    try:
        data = PromptRequest(prompt=prompt, character_name=character_name, setting=setting, tone=tone, art_style=art_style)
        layout, pdf_path = create_comic(data)
        return request.app.state.templates.TemplateResponse(request=request, name="comic_preview.html", context={"layout": layout, "pdf_path": pdf_path})
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Comic generation failed: {exc}") from exc

@router.post("/generate-comic/json")
def generate_json(data: PromptRequest):
    try:
        layout, pdf_path = create_comic(data)
        return {"message": "Comic generated", "layout": layout, "pdf_path": pdf_path}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Comic generation failed: {exc}") from exc

@router.get("/export-success", response_class=HTMLResponse)
def export_success(request: Request, file: Optional[str] = None):
    return request.app.state.templates.TemplateResponse(request=request, name="export_success.html", context={"pdf_path": file})

@router.get("/download")
def download_pdf(file: str):
    # Only permit files in this application's export folder.
    exports_dir = (Path(__file__).resolve().parent / "static" / "exports").resolve()
    candidate = (exports_dir / Path(file).name).resolve()
    if candidate.parent != exports_dir or not candidate.exists() or candidate.suffix.lower() != ".pdf":
        raise HTTPException(status_code=404, detail="PDF not found")
    return FileResponse(candidate, media_type="application/pdf", filename=candidate.name)

@router.get("/test-image")
def test_image(prompt: str = "A friendly robot exploring a colorful city in comic-book style"):
    return {"image_path": generate_image(prompt, 99), "prompt": prompt}
