# ComicCraft — AI Comic Story Creator

A FastAPI web application that turns a prompt into a five-panel comic outline, narration, dialogue, illustrations, and a downloadable PDF.

## Features
- Responsive HTML/CSS interface with Jinja2 templates
- Five-panel outline generation via Gemini when `GEMINI_API_KEY` is set
- Narration and dialogue generation via Gemini when configured
- Optional Hugging Face image generation
- Demo mode works without API keys (uses sample story content and SVG panel placeholders)
- PDF export and JSON API endpoint
- FastAPI Swagger UI at `/docs`

## Requirements
- Python 3.10 or newer
- Internet connection to install dependencies
- Optional Gemini API key for live story generation
- Optional Hugging Face token for live image generation

## Run on Windows
1. Extract the ZIP and open the `comiccraft_project` folder in VS Code.
2. Open a terminal in that folder.
3. Run `run_windows.bat`, or run these commands manually:

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```

## Run on macOS/Linux
```bash
chmod +x run_unix.sh
./run_unix.sh
```

Then open `http://127.0.0.1:8000`. API docs: `http://127.0.0.1:8000/docs`.

## Configure AI (optional)
Edit `.env` and add keys you obtain from the relevant providers:

```env
GEMINI_API_KEY=your_key_here
GEMINI_FLASH_MODEL=gemini-2.5-flash
GEMINI_PRO_MODEL=gemini-2.5-pro
HF_API_KEY=your_huggingface_token_here
HF_IMAGE_MODEL=stabilityai/stable-diffusion-xl-base-1.0
```

Never commit `.env` or share your API keys. Without keys, ComicCraft still runs in demo mode. Live image generation may require provider access/credits and compatible model availability.

## Project structure
```text
comiccraft_project/
├── app/
│   ├── main.py
│   ├── routes.py
│   ├── gemini_flash.py
│   ├── gemini_pro.py
│   ├── image_generator.py
│   ├── layout_builder.py
│   ├── exporters.py
│   ├── templates/
│   │   ├── index.html
│   │   ├── comic_preview.html
│   │   └── export_success.html
│   └── static/
│       ├── css/style.css
│       ├── panels/
│       └── exports/
├── requirements.txt
├── .env.example
├── run_windows.bat
├── run_unix.sh
└── README.md
```

## Main routes
- `GET /` — homepage
- `POST /generate` — create a comic from the web form
- `POST /generate-comic/json` — create a comic from JSON
- `GET /test-image?prompt=...` — test illustration generation
- `GET /download?file=...` — download an exported PDF
- `GET /docs` — interactive API documentation
- `GET /health` — health check

Example JSON body for `/generate-comic/json`:
```json
{
  "prompt": "A young inventor discovers a friendly robot",
  "character_name": "Mira",
  "setting": "a floating city",
  "tone": "adventurous",
  "art_style": "anime"
}
```

## Notes
- This is a student-project starter implementation aligned with the supplied ComicCraft specification.
- The application is configured for local development, not production deployment. Add authentication, rate limits, logging, and secure hosting before public deployment.
